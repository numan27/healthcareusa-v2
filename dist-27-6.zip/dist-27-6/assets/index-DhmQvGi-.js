import{j as e}from"./index-r2Al1Vyr.js";function r(){return e.jsx("div",{children:e.jsx("h2",{children:"No Page Found."})})}export{r as default};
