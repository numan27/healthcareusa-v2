import{j as e}from"./index-Cz8lS7uP.js";function r(){return e.jsx("div",{children:e.jsx("h2",{children:"No Page Found."})})}export{r as default};
